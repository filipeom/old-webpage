#include <stdlib.h>

void test() {
  int *ptr = NULL;
  *ptr = 42;
}
